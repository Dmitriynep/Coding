public class Main {

    public static void main(String[] args) {
        Basket basket = new Basket();
        Basket basket1 = new Basket();
        basket.add("Milk", 40);
        basket1.add("Smth.", 150, 5, 12.5);
        basket.print("Milk");
        basket1.print("Smth");
        System.out.println(basket1.getTotalWeight());
    }
}
