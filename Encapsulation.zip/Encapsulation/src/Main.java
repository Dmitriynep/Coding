import java.util.Scanner; // Сканнер подключен для лифта

public class Main {
    public static void main(String[] args) {

// Dimensions set

        Dimensions oldSchoolTv = new Dimensions(80,60,55);


        Cargo oldSchoolTvCargo = new Cargo(oldSchoolTv.dimensions(),55," Шоумяна д. 14 ", true, "12-AFGHJKOP", false);


        Cargo copy  = oldSchoolTvCargo.setAdressDelivery(" Бронтазавров д. 53");

        copy.setWeight(155); // Присвоение не выполняется т.к. класс иммутабельный

        System.out.println(copy.getDimensions() + copy.getAdressDelivery() + " " + copy.getWeight());

        Cargo copy2 = oldSchoolTvCargo.setWeight(155);

        System.out.println(copy2.getDimensions() + copy2.getAdressDelivery() + " " + copy2.getWeight());

        Cargo copy3 = copy.setDimensions("Ширина - 75.5 см. Высота - 63.3 см. Длина - 40.4 см.");

        System.out.println(copy3.getDimensions() + copy3.getAdressDelivery() + " " + copy3.getWeight());

        System.out.println(oldSchoolTvCargo.getDimensions() + " " + oldSchoolTvCargo.getWeight() + oldSchoolTvCargo.getAdressDelivery());



/*// elevator
*//*        Elevator elevator = new Elevator(-3, 26);
        while (true) {
            System.out.print("Введите номер этажа: ");
            int floor = new Scanner (System.in).nextInt();
            elevator.move(floor);
        }*/

    }
}