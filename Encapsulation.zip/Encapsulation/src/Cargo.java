public class Cargo {

    private final String dimensions;
    private final double weight;
    private final String adressDelivery;
    private final boolean turnOk;
    private final String regNmbr;
    private final boolean isFragile;

    public Cargo(String dimensions, double weight, String adressDelivery, boolean turnOk, String regNmbr, boolean isFragile) {
        this.dimensions = dimensions;
        this.weight = weight;
        this.adressDelivery = adressDelivery;
        this.turnOk = turnOk;
        this.regNmbr = regNmbr;
        this.isFragile = isFragile;
    }

    public Cargo setAdressDelivery (String adressDelivery) {
        return new Cargo(dimensions,weight,adressDelivery,turnOk,regNmbr,isFragile);
    }

    public Cargo setWeight (double weight) {
        return new Cargo(dimensions,weight,adressDelivery,turnOk,regNmbr,isFragile);
    }

    public Cargo setDimensions (String dimensions) {
        return new Cargo(dimensions,weight,adressDelivery,turnOk,regNmbr,isFragile);
    }

    public String getDimensions() {
        return dimensions;
    }

    public double getWeight() {
        return weight;
    }

    public String getAdressDelivery() {
        return adressDelivery;
    }

    public boolean isTurnOk() {
        return turnOk;
    }

    public String getRegNmbr() {
        return regNmbr;
    }

    public boolean isFragile() {
        return isFragile;
    }
}
